const Products = require("../models/Products");

Products.sync();
