const express = require("express");
const router = express.Router();

const indexController = require("../controllers/indexController");
const addProductsController = require("../controllers/addProductsController");
const editProductsController = require("../controllers/editProductsController");
const deleteProductsController = require("../controllers/deleteProductsController");
const findProductsByIdController = require("../controllers/findProductsByIdController");

//index ou busca todos os Products
router.get("/", indexController.renderPage);

//adiciona Products
router.get("/addProducts", addProductsController.renderPage);
router.post("/addProducts", addProductsController.addProducts);

//edita Products
router.get("/editProducts/:uuid", editProductsController.renderPage);
router.post("/editProducts", editProductsController.editProducts);

//deleta Products
router.post("/deleteProducts", deleteProductsController.deleteProducts);

//busca por id
router.get("/Products/:ProductsId", findProductsByIdController.renderProductsById);

module.exports = router;
