const Products = require("../models/Products");

const renderProductsById = async (req, res) => {
    const products = await Products.findByPk(req.params.ProductsId);

   if (products) {
       return res.render("products", {
           products
       });
   }

   return res.redirect("/?error=ProductsNotFound");
}


module.exports = { renderProductsById };