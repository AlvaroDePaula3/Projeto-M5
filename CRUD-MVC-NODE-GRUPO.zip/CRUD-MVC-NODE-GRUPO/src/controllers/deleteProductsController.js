const Products = require("../models/Products");

const deleteProducts = async (req, res) => {
    
    if (req.query.uuid == undefined || req.query.uuid == null) {
        return res.redirect("/?error=noProductsSpecified");
    };
    
    await Products.destroy({
        where: {
            uuid: req.query.uuid,
        }
    });

    return res.redirect("/");
};

module.exports = { 
   deleteProducts
};
