const Products = require("../models/Products");

const renderPage = async (req, res) => {
    const productsData = [];

    const productss = await Products.findAll();
    productss.forEach(Products => ProductsData.push(products));
    return res.render("index", {
        productsData
    });
}

module.exports = { renderPage };
