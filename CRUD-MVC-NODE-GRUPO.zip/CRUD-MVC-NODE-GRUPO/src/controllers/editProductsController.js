const Products = require("../models/Products");

const renderPage = async (req, res) => {
    const Products = await Products.findOne({
        where: {
            uuid: req.params.uuid,
        }
    });

   if (products) {
       return res.render("edit", {
           Products
       });
   }

   return res.redirect("/?error=ProductsNotFound");
}

const editProducts = async (req, res) => {
    const {  name, category, price } = req.body;
    
    Products.findOne({
        where: {
            uuid: req.query.uuid,
        }
    }).then((products) => {
        products.update({  name, category, price });
        return res.redirect("/");
    }).catch(() => {
        return res.redirect("/?error=invalidUUID");
    });
}

module.exports = {
    renderPage, editProducts
};
