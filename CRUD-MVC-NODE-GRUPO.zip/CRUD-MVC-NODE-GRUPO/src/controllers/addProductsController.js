const Products = require("../models/Products");

const renderPage = (req, res) => {
    return res.render("addProducts");
};

const addProducts = async (req, res) => {
    const { name, category, price } = req.body;

    const productsExist = await Products.findOne({
        where: {
            category
        }
    });

    if (!productsExist) {        
        if (name && category && price !== null) {
            const productsCreated = await Products.create({ name, category, price });
            console.log(`Products ${productsCreated.name} created with UUID of: ${productsCreated.uuid}`);
            return res.redirect("/");
        }
    }

    return res.redirect("/?error=categoryTaken");
};

module.exports = {
    renderPage, addProducts
}
